--
-- código fonte disponível do arquivo cap_1_script_3.sql
--

DECLARE
	v_nr_cliente 			number(7) 			:= 17;
	v_verifica_estoque		boolean 			:= TRUE;
	v_nr_limite_credito 	CONSTANT number(5)	:= 9730;
BEGIN
	NULL; -- Dentro de um bloco PL/SQL é necessário ter um comando válido e "NULL;" é considerado um desses comandos.
END;
